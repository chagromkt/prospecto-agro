import { useState } from 'react'
import Sidebar from './components/Sidebar.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Listas from './pages/Listas.jsx'
import Leads from './pages/Leads.jsx'
import Campanhas from './pages/Campanhas.jsx'
import Agentes from './pages/Agentes.jsx'
import Conteudo from './pages/Conteudo.jsx'
import Comentarios from './pages/Comentarios.jsx'

const PAGES = { dashboard: Dashboard, listas: Listas, leads: Leads, campanhas: Campanhas, agentes: Agentes, conteudo: Conteudo, comentarios: Comentarios }

export default function App() {
  const [page, setPage] = useState('dashboard')
  const Page = PAGES[page] || Dashboard

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar page={page} setPage={setPage} />
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <Page />
      </div>
    </div>
  )
}
